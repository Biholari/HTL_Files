public class Main {
    public static void main(String[] args) {
        Tree t = new Tree();

        t.add(17);
        t.add(10);
        t.add(20);
        t.add(12);
        t.add(13);
        System.out.println(t);
    }
}